# easystruct
A Python library to make the usage of struct from the stdlib a little bit easier.

## Installation

```bash
pip3 install easystruct
```
